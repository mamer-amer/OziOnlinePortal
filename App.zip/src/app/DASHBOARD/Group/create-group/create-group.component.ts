import { MemberService } from './../../../../services/member.service';
import { GroupService } from './../../../../services/group.service';
import { Group } from './../../../../models/group';
import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { EnumService } from 'src/services/enum.service';
import { IDropdownSettings } from 'ng-multiselect-dropdown';

@Component({
  selector: 'app-create-group',
  templateUrl: './create-group.component.html',
  styleUrls: ['./create-group.component.css']
})
export class CreateGroupComponent implements OnInit {
  groupDto: Group = new Group();
  membersList = [];
  routeId: any = undefined;
  dropdownList = [];
  selectedItems = [];
  dropdownSettings = {};
 
  constructor(private groupService: GroupService, private memberService: MemberService, private router: Router, private activatedRoute: ActivatedRoute, private toastService: ToastrService, private enumService: EnumService) { }
  moduleId:any;
  ngOnInit(): void {
    this.activatedRoute
    .queryParams
    .subscribe((params)=> {

      this.moduleId = params['moduleId'];

    });

    this.getMembers();
    
    this.dropdownSettings = {
      singleSelection: false,
      idField: "memberId",
      textField: "name",
      selectAllText: "Select All",
      unSelectAllText: "UnSelect All",
      itemsShowLimit: 10,
      allowSearchFilter: true,
      limitSelection: 100
    };
    this.getStatus();
    this.getRouteId();
    if (this.routeId != undefined) {
      this.getById();
      
    }
    

   
    


  }


  save() {

    if (this.routeId == undefined) {
      this.groupService.create(this.groupDto).subscribe(res => {
        if (res) {
          this.toastService.success('Successfully Added')
          this.router.navigate(['layout/view/group'],{queryParams:{moduleId:this.moduleId}})
        }
      })
    }
    else {
      this.groupService.update(this.groupDto).subscribe(res => {
        if (res) {
          this.toastService.success('Successfully Updated')

          this.router.navigate(['layout/view/group'],{queryParams:{moduleId:this.moduleId}})
        }
      })
    }

  }



  getRouteId() {
    this.activatedRoute.params.subscribe(params => {
      this.routeId = params['id'];
    });
  }

  getById() {
    this.groupService.getById(this.routeId).subscribe(res => {
      if (res) {
        this.groupDto = res;
        // this.membersList = res.memberIds;
      }
    })
  }
  back(){
    window.history.go(-1);
  }

  status = []
  getStatus() {
    this.status = this.enumService.status
    this.groupDto.status = 0;
    
  }

  getMembers() {
    this.memberService.getAll().subscribe(res => {
      this.membersList = res;
    })
  }

  onItemSelect(item: any) {
    //select on member
    let id = item.memberId;
    this.groupDto.memberIds.push(id);
  }
  onSelectAll(items: any) {


    console.log(items);
  }
  onItemDeSelect(items: any) {
  
      this.groupDto.memberIds = this.groupDto.memberIds.filter(item=>item !=items.memberId)
  }


}
