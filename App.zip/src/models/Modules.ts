export class Modules {
    moduleId:any;
    name:any;
    institutionId:any;
    code:any;
    description:any;
    icon:any;
    route:any;
}