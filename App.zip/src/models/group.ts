export class Group {
    groupId:any;
    name:any;
    code:any;
    description:any;
    memberIds :any= [];
    status:number=0;
}