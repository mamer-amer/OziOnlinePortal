export class Contribution {
    Name: string;
    fundTypeId: any=1;
    contributionId:any;
    contributionType: any;
    paymentType: any;
    checkNo: string;
    amount: number;
    memo: string;
}