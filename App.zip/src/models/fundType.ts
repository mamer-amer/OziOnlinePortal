export class FundType{
    Code:any;
    fundTypeId:number;
    name:any;
    Campus:any;
    revenueId:any=null;
    CheckId:any=null;
    comment:any;
    status:any=0;
}