export class ModuleAction{
    moduleId?:number;
    actionId?:number;
}