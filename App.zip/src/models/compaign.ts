export class Compaign {
    campaignGoal: string;
    campaignId:any;
    fundTypeId: number=null;
    StartDateTime:any;
    EndDateTime:any;
    createdDateTime:any;
    updatedDate:any;
    VisibleDateTime:any;
    status: any=0;
}