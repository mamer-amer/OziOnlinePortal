export class Revenue {
    code: string;
    revenueId:any;
    name: string;
    status: any = 0;
}
