export class Pledge {
    campaignId: any;
    pledgeId:any;
    name: string;
    amount: number;
    frequency: any=0;
    StartDateTime:any;
    EndDateTime:any;
}