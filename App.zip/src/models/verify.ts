export class Verify{
    PhoneNumber?:any="";
    Code?:any=""
}