export class login{
    PhoneNumber?:any=null;
    UserName?:any=null;
}


