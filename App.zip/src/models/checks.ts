export class Check {

   public checkId?: any;
   public Name?: any;
   public Code?: any;
   public createdDateTime?: any;
   public updatedDateTime?: any;
   public createdBy?: any;
   public updatedBy?: any;
   public Status?: any=0;
   public licenseManagement?: any;
   public  licenseManagementId?: any;
}   