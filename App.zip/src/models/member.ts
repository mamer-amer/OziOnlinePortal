
export class Member{
    name:any;
    memberId:any
    code:any;
    profilePicture:any;
    address:any;
    email:any;
    phone:any;
    gender:number=0;
    maritalStatus:number=0;
    familyPosition:number=0;
    anniversary:any;
    familyLinkCode:any;
    birthdayMonth:number=0;
    birthdayDay:number=0;
    dateJoined:any
    membershipStatus:number=0;
    privacyLevel:number=0;

}